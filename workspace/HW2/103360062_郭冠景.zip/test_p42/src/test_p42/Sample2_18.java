package test_p42;

public class Sample2_18 {
	public static void main(String[] args)
	{
		int[] test={80,60,22,50,75};
		
		for(int i=0;i<5;i++)
		{
			System.out.println("��"+(i+1)+"�ӤH�����ƬO"+test[i]+"��");
		}
	}
}
