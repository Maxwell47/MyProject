package test_p25;

public class Sample_7 {
	public static void main(String[] args)
	{
		int num;
		num = 3;
		System.out.println("�ܼ�num���ȬO"+num);
	}

}
